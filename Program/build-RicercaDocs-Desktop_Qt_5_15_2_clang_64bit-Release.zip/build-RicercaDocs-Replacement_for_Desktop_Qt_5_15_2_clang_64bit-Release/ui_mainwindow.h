/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionAbout;
    QAction *actionCredits;
    QAction *actionChangeFont;
    QAction *actionExit;
    QAction *actionCut;
    QAction *actionCopy;
    QAction *actionPaste;
    QAction *actionOpen;
    QAction *actionUndo;
    QAction *actionRedo;
    QAction *actionExport;
    QAction *actionEncrypt;
    QAction *actionNew;
    QAction *actionSave;
    QAction *actionAuto_Encrypt;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QFrame *frame;
    QGridLayout *gridLayout_2;
    QTextEdit *textEdit;
    QTabWidget *tabWidget;
    QWidget *design;
    QGridLayout *gridLayout_3;
    QPushButton *openFile;
    QPushButton *fontColor;
    QPushButton *font;
    QSpacerItem *horizontalSpacer;
    QPushButton *insertImage;
    QPushButton *insertChart;
    QPushButton *newFile;
    QWidget *manage;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *exportPDF;
    QPushButton *encrypt;
    QSpacerItem *horizontalSpacer_2;
    QStatusBar *statusbar;
    QMenuBar *menubar;
    QMenu *menuView;
    QMenu *menuHelp;
    QMenu *menuEdit;
    QMenu *menuFile;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1000, 700);
        MainWindow->setMinimumSize(QSize(1000, 700));
        MainWindow->setMaximumSize(QSize(16777215, 16777215));
        QIcon icon;
        icon.addFile(QStringLiteral(":/assets/screen/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(true);
        MainWindow->setStyleSheet(QStringLiteral(""));
        MainWindow->setTabShape(QTabWidget::Rounded);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionCredits = new QAction(MainWindow);
        actionCredits->setObjectName(QStringLiteral("actionCredits"));
        actionChangeFont = new QAction(MainWindow);
        actionChangeFont->setObjectName(QStringLiteral("actionChangeFont"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/assets/icons/font.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionChangeFont->setIcon(icon1);
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QStringLiteral("actionExit"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/assets/icons/exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExit->setIcon(icon2);
        actionCut = new QAction(MainWindow);
        actionCut->setObjectName(QStringLiteral("actionCut"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/assets/icons/cut.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCut->setIcon(icon3);
        actionCopy = new QAction(MainWindow);
        actionCopy->setObjectName(QStringLiteral("actionCopy"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/assets/icons/copy.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCopy->setIcon(icon4);
        actionPaste = new QAction(MainWindow);
        actionPaste->setObjectName(QStringLiteral("actionPaste"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/assets/icons/paste.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPaste->setIcon(icon5);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/assets/icons/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon6);
        actionUndo = new QAction(MainWindow);
        actionUndo->setObjectName(QStringLiteral("actionUndo"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/assets/icons/undo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionUndo->setIcon(icon7);
        actionRedo = new QAction(MainWindow);
        actionRedo->setObjectName(QStringLiteral("actionRedo"));
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/assets/icons/redo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRedo->setIcon(icon8);
        actionExport = new QAction(MainWindow);
        actionExport->setObjectName(QStringLiteral("actionExport"));
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/assets/icons/pdf.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExport->setIcon(icon9);
        actionEncrypt = new QAction(MainWindow);
        actionEncrypt->setObjectName(QStringLiteral("actionEncrypt"));
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/assets/icons/encryption.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionEncrypt->setIcon(icon10);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/assets/icons/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon11);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon12;
        icon12.addFile(QStringLiteral(":/assets/icons/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon12);
        actionAuto_Encrypt = new QAction(MainWindow);
        actionAuto_Encrypt->setObjectName(QStringLiteral("actionAuto_Encrypt"));
        actionAuto_Encrypt->setCheckable(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        centralwidget->setStyleSheet(QStringLiteral("background-color: rgb(230, 230, 230);"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 0);
        frame = new QFrame(centralwidget);
        frame->setObjectName(QStringLiteral("frame"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setMinimumSize(QSize(0, 0));
        frame->setAutoFillBackground(false);
        frame->setStyleSheet(QStringLiteral(""));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Raised);
        frame->setLineWidth(0);
        frame->setMidLineWidth(0);
        gridLayout_2 = new QGridLayout(frame);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setHorizontalSpacing(6);
        gridLayout_2->setVerticalSpacing(10);
        gridLayout_2->setContentsMargins(6, 6, 6, 6);
        textEdit = new QTextEdit(frame);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        QFont font1;
        font1.setFamily(QStringLiteral("Times New Roman"));
        font1.setPointSize(12);
        textEdit->setFont(font1);
        textEdit->setStyleSheet(QLatin1String("\n"
"background-color: rgb(255, 255, 255);"));
        textEdit->setFrameShape(QFrame::NoFrame);
        textEdit->setFrameShadow(QFrame::Plain);
        textEdit->setLineWidth(1);

        gridLayout_2->addWidget(textEdit, 2, 0, 1, 1);

        tabWidget = new QTabWidget(frame);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setEnabled(true);
        tabWidget->setMinimumSize(QSize(0, 100));
        tabWidget->setMaximumSize(QSize(16777215, 115));
        tabWidget->setAutoFillBackground(false);
        tabWidget->setStyleSheet(QStringLiteral("background-color: rgb(250, 250, 250);"));
        tabWidget->setTabsClosable(false);
        design = new QWidget();
        design->setObjectName(QStringLiteral("design"));
        gridLayout_3 = new QGridLayout(design);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        openFile = new QPushButton(design);
        openFile->setObjectName(QStringLiteral("openFile"));
        openFile->setMinimumSize(QSize(0, 60));
        QFont font2;
        font2.setFamily(QStringLiteral("Arial Nova Light"));
        font2.setPointSize(10);
        openFile->setFont(font2);
        openFile->setFocusPolicy(Qt::StrongFocus);
        openFile->setLayoutDirection(Qt::LeftToRight);
        openFile->setAutoFillBackground(false);
        openFile->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        openFile->setIcon(icon6);
        openFile->setIconSize(QSize(60, 60));
        openFile->setFlat(true);

        gridLayout_3->addWidget(openFile, 1, 1, 1, 1);

        fontColor = new QPushButton(design);
        fontColor->setObjectName(QStringLiteral("fontColor"));
        fontColor->setMinimumSize(QSize(0, 60));
        fontColor->setFont(font2);
        fontColor->setFocusPolicy(Qt::StrongFocus);
        fontColor->setLayoutDirection(Qt::LeftToRight);
        fontColor->setAutoFillBackground(false);
        fontColor->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        QIcon icon13;
        icon13.addFile(QStringLiteral(":/assets/icons/fontColor.png"), QSize(), QIcon::Normal, QIcon::Off);
        fontColor->setIcon(icon13);
        fontColor->setIconSize(QSize(60, 60));
        fontColor->setFlat(true);

        gridLayout_3->addWidget(fontColor, 1, 3, 1, 1);

        font = new QPushButton(design);
        font->setObjectName(QStringLiteral("font"));
        font->setMinimumSize(QSize(0, 60));
        font->setFont(font2);
        font->setFocusPolicy(Qt::StrongFocus);
        font->setLayoutDirection(Qt::LeftToRight);
        font->setAutoFillBackground(false);
        font->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        font->setIcon(icon1);
        font->setIconSize(QSize(60, 60));
        font->setFlat(true);

        gridLayout_3->addWidget(font, 1, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 1, 6, 1, 1);

        insertImage = new QPushButton(design);
        insertImage->setObjectName(QStringLiteral("insertImage"));
        insertImage->setMinimumSize(QSize(0, 60));
        insertImage->setFont(font2);
        insertImage->setFocusPolicy(Qt::StrongFocus);
        insertImage->setLayoutDirection(Qt::LeftToRight);
        insertImage->setAutoFillBackground(false);
        insertImage->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        QIcon icon14;
        icon14.addFile(QStringLiteral(":/assets/icons/image.png"), QSize(), QIcon::Normal, QIcon::Off);
        insertImage->setIcon(icon14);
        insertImage->setIconSize(QSize(60, 60));
        insertImage->setFlat(true);

        gridLayout_3->addWidget(insertImage, 1, 4, 1, 1);

        insertChart = new QPushButton(design);
        insertChart->setObjectName(QStringLiteral("insertChart"));
        insertChart->setMinimumSize(QSize(0, 60));
        insertChart->setFont(font2);
        insertChart->setFocusPolicy(Qt::StrongFocus);
        insertChart->setLayoutDirection(Qt::LeftToRight);
        insertChart->setAutoFillBackground(false);
        insertChart->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        QIcon icon15;
        icon15.addFile(QStringLiteral(":/assets/icons/chart.png"), QSize(), QIcon::Normal, QIcon::Off);
        insertChart->setIcon(icon15);
        insertChart->setIconSize(QSize(60, 60));
        insertChart->setFlat(true);

        gridLayout_3->addWidget(insertChart, 1, 5, 1, 1);

        newFile = new QPushButton(design);
        newFile->setObjectName(QStringLiteral("newFile"));
        newFile->setMinimumSize(QSize(0, 60));
        newFile->setFont(font2);
        newFile->setFocusPolicy(Qt::StrongFocus);
        newFile->setLayoutDirection(Qt::LeftToRight);
        newFile->setAutoFillBackground(false);
        newFile->setStyleSheet(QLatin1String("background-color: rgb(240, 240, 240);\n"
"text-align:bottom;"));
        newFile->setIcon(icon11);
        newFile->setIconSize(QSize(60, 60));
        newFile->setFlat(true);

        gridLayout_3->addWidget(newFile, 1, 0, 1, 1);

        tabWidget->addTab(design, QString());
        manage = new QWidget();
        manage->setObjectName(QStringLiteral("manage"));
        horizontalLayout_3 = new QHBoxLayout(manage);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        exportPDF = new QPushButton(manage);
        exportPDF->setObjectName(QStringLiteral("exportPDF"));
        exportPDF->setMinimumSize(QSize(0, 60));
        exportPDF->setFont(font2);
        exportPDF->setFocusPolicy(Qt::StrongFocus);
        exportPDF->setLayoutDirection(Qt::LeftToRight);
        exportPDF->setAutoFillBackground(false);
        exportPDF->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        exportPDF->setIcon(icon9);
        exportPDF->setIconSize(QSize(60, 60));
        exportPDF->setFlat(true);

        horizontalLayout_3->addWidget(exportPDF);

        encrypt = new QPushButton(manage);
        encrypt->setObjectName(QStringLiteral("encrypt"));
        encrypt->setMinimumSize(QSize(0, 60));
        encrypt->setFont(font2);
        encrypt->setFocusPolicy(Qt::StrongFocus);
        encrypt->setLayoutDirection(Qt::LeftToRight);
        encrypt->setAutoFillBackground(false);
        encrypt->setStyleSheet(QStringLiteral("background-color: rgb(240, 240, 240);"));
        encrypt->setIcon(icon10);
        encrypt->setIconSize(QSize(60, 60));
        encrypt->setFlat(true);

        horizontalLayout_3->addWidget(encrypt);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        tabWidget->addTab(manage, QString());

        gridLayout_2->addWidget(tabWidget, 1, 0, 1, 1);


        gridLayout->addWidget(frame, 1, 0, 2, 1);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1000, 25));
        menuView = new QMenu(menubar);
        menuView->setObjectName(QStringLiteral("menuView"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        menuEdit = new QMenu(menubar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuEdit->menuAction());
        menubar->addAction(menuView->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menuView->addAction(actionExport);
        menuView->addAction(actionEncrypt);
        menuView->addAction(actionAuto_Encrypt);
        menuHelp->addSeparator();
        menuHelp->addAction(actionAbout);
        menuHelp->addAction(actionCredits);
        menuEdit->addAction(actionUndo);
        menuEdit->addAction(actionRedo);
        menuEdit->addAction(actionCut);
        menuEdit->addAction(actionCopy);
        menuEdit->addAction(actionPaste);
        menuEdit->addAction(actionChangeFont);
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addAction(actionExit);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Ricerca Docs", Q_NULLPTR));
        actionAbout->setText(QApplication::translate("MainWindow", "About", Q_NULLPTR));
        actionCredits->setText(QApplication::translate("MainWindow", "Credits", Q_NULLPTR));
        actionChangeFont->setText(QApplication::translate("MainWindow", "Change Font", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionChangeFont->setToolTip(QApplication::translate("MainWindow", "Change document font", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionExit->setText(QApplication::translate("MainWindow", "Exit", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionExit->setToolTip(QApplication::translate("MainWindow", "Exit the application", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionExit->setShortcut(QApplication::translate("MainWindow", "Ctrl+W", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionCut->setText(QApplication::translate("MainWindow", "Cut", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionCut->setToolTip(QApplication::translate("MainWindow", "Cut text", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionCut->setShortcut(QApplication::translate("MainWindow", "Ctrl+X", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionCopy->setText(QApplication::translate("MainWindow", "Copy", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionCopy->setToolTip(QApplication::translate("MainWindow", "Copy text", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionCopy->setShortcut(QApplication::translate("MainWindow", "Ctrl+C", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionPaste->setText(QApplication::translate("MainWindow", "Paste", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionPaste->setToolTip(QApplication::translate("MainWindow", "Paste text", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionPaste->setShortcut(QApplication::translate("MainWindow", "Ctrl+V", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionOpen->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionOpen->setToolTip(QApplication::translate("MainWindow", "Open Document", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionOpen->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionUndo->setText(QApplication::translate("MainWindow", "Undo", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionUndo->setToolTip(QApplication::translate("MainWindow", "Undo", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionUndo->setShortcut(QApplication::translate("MainWindow", "Ctrl+Z", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionRedo->setText(QApplication::translate("MainWindow", "Redo", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionRedo->setToolTip(QApplication::translate("MainWindow", "Redo", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionRedo->setShortcut(QApplication::translate("MainWindow", "Ctrl+Y", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionExport->setText(QApplication::translate("MainWindow", "Export File", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionExport->setToolTip(QApplication::translate("MainWindow", "Export to PDF", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionExport->setShortcut(QApplication::translate("MainWindow", "Ctrl+P", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionEncrypt->setText(QApplication::translate("MainWindow", "Encrypt File", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionEncrypt->setToolTip(QApplication::translate("MainWindow", "Encrypt document", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionEncrypt->setShortcut(QApplication::translate("MainWindow", "Ctrl+E", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionNew->setText(QApplication::translate("MainWindow", "New", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionNew->setToolTip(QApplication::translate("MainWindow", "Create new document", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionNew->setShortcut(QApplication::translate("MainWindow", "Ctrl+N", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionSave->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionSave->setToolTip(QApplication::translate("MainWindow", "Save document", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionSave->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        actionAuto_Encrypt->setText(QApplication::translate("MainWindow", "Auto Encrypt", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionAuto_Encrypt->setToolTip(QApplication::translate("MainWindow", "Automatically encrypt file during save", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        textEdit->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Times New Roman'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", Q_NULLPTR));
        openFile->setText(QApplication::translate("MainWindow", "Open File", Q_NULLPTR));
        fontColor->setText(QApplication::translate("MainWindow", "Font Color", Q_NULLPTR));
        font->setText(QApplication::translate("MainWindow", "Font Type", Q_NULLPTR));
        insertImage->setText(QApplication::translate("MainWindow", "Add Image", Q_NULLPTR));
        insertChart->setText(QApplication::translate("MainWindow", "Add  Chart", Q_NULLPTR));
        newFile->setText(QApplication::translate("MainWindow", "New File", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(design), QApplication::translate("MainWindow", "Design", Q_NULLPTR));
        exportPDF->setText(QApplication::translate("MainWindow", "Export to PDF", Q_NULLPTR));
        encrypt->setText(QApplication::translate("MainWindow", "Encrypt Document", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(manage), QApplication::translate("MainWindow", "Manage", Q_NULLPTR));
        menuView->setTitle(QApplication::translate("MainWindow", "Tools", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", Q_NULLPTR));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Edit", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
